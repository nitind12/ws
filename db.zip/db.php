<?php
  	$servername = "localhost";
  	//$username = "root";
	//$password = "";
	//$db = "daily_exp";

	$username = "dproot";
	$password = "bLK*=!=uZ+]S";
	$db = "amrapali_dexp";

// Create connection
$con = new mysqli($servername, $username, $password, $db);
?>